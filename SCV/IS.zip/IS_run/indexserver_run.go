package main
import (
  	"fmt"
  	"net"
  	"encoding/json"
  	"log"
    "gopkg.in/mgo.v2"
    "gopkg.in/mgo.v2/bson"
    "os"
)
var databaseAddr string 
var databaseName string
var collectionName string
type indexServer struct{
  ReqType int
  Name string
  IpAddr string
  ID bson.ObjectId `bson:"_id,omitempty"`
}

func ClientListen() {
  	ln, err := net.Listen("tcp", ":9999")
  	if err != nil {
    		fmt.Println("error\n")
    		fmt.Println(err)
    	return
  	}
  	for {
    		// accept a connection
    		c, err := ln.Accept()
    		if err != nil {
      			fmt.Println(err)
      			continue
    		}
   		go recivemsg(c)
  	}
}

func recivemsg(c net.Conn){
		var msg []byte
  		var ans indexServer
  		err := json.NewDecoder(c).Decode(&msg)
  		e := json.Unmarshal(msg,&ans) 
  		var SendOut indexServer
  		if e != nil {
    			fmt.Println(e)
   			return
  		}  
		if err != nil {
    			fmt.Println(err)
  		} else {
    			 fmt.Println("Received ", ans.ReqType)
    			 fmt.Println("Received:: ", ans)
           if(ans.ReqType==0){
            SendOut = queryByCode(ans.ID.Hex())
                b,_ := json.Marshal(SendOut)  
                json.NewEncoder(c).Encode(b)
                
           }else if(ans.ReqType==1){
            
            SendOut = queComName(ans.Name)
            SendOut1 := SendOut
            SendOut1.IpAddr = ans.IpAddr
            update(databaseAddr,SendOut,SendOut1,databaseName,collectionName )
            SendOut = queComName(ans.Name)
            b,_ := json.Marshal(SendOut)  
            json.NewEncoder(c).Encode(b)
           }
  		}

      c.Close()
}


/**
 * @description the function handles an mongodb error, user input an err
  or the function prints the error if the error is not nil
 * @param  err the error user wants to handle
 * @return void
*/
func errhandler(err error) {
  if err != nil {
        log.Fatal(err)
        return
    }
}
func update(databaseAddr string,old indexServer,new indexServer,database string,collection string ){
     session, err := mgo.Dial(databaseAddr)
     errhandler(err)
     defer session.Close()
     session.SetMode(mgo.Monotonic, true)
     d := session.DB(database).C(collection)
     err = d.Update(old,new)
}
func queryByCode(hexID string)indexServer{
  session, err := mgo.Dial(databaseAddr)
  if err != nil {
    panic(err)
  }  
  defer session.Close()

  session.SetMode(mgo.Monotonic, true)
  c := session.DB(databaseName).C(collectionName)

  var result indexServer
  c.FindId(bson.ObjectIdHex(hexID)).One(&result) 
  if err != nil {
      log.Fatal(err)        
  }
  return   result
}

func queComName(comName string)(Record indexServer){
  session, err := mgo.Dial(databaseAddr)
  if err != nil {
    panic(err)
  }  
  defer session.Close()

  session.SetMode(mgo.Monotonic, true)
  c := session.DB(databaseName).C(collectionName)
  
  var record indexServer
  fmt.Println(comName)
  err = c.Find(bson.M{"name": comName}).One(&record)
  if err != nil {
    panic(err)
  }
  return record
}



func main() {

/*	var databaseAddr string 
var databaseName string
var collectionName string
	*/
if(len(os.Args)<4){
	fmt.Println("not enough arguments input")
	return;
}
if(len(os.Args)>4){
		fmt.Println("too many arguments")

		return;
}

	databaseAddr=os.Args[1]
	databaseName=os.Args[2]
	collectionName=os.Args[3]
	ClientListen()

  //fmt.Println("Record: ", queComName("Pepsi"))
	}

































/*func query(keyword string, ReqType int)([]string,[]string){

  var typename string
  
  if (ReqType==0){
    typename="Supp"
  }else if(ReqType==1){
    typename="Order"}
  
        session, err := mgo.Dial("localhost")
        if err != nil {
                panic(err)
        }
        defer session.Close()
        session.SetMode(mgo.Monotonic, true)
        c := session.DB("indexserver").C(typename)
        result := []Supp{}
    
        err = c.Find(bson.M{"name": keyword}).All(&result)
        if err != nil {
                log.Fatal(err)        
        }
      TempIP:=make( []string,len(result))
      TempName:= make([]string,len(result));  
      
      for i:=0; i<len(result); i++{
          fmt.Println("Name", result[i].Name, "IP:", result[i].IpAddr)
    TempIP[i] = result[i].IpAddr
          TempName[i] = result[i].Name
        }
        return TempIP,TempName
}
*/