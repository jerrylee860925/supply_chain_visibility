package main

import (
 "log"
 "gopkg.in/mgo.v2"
 "gopkg.in/mgo.v2/bson"
// "strconv"
 "fmt"
// "bufio"
 "os"


)

var databaseAddr string
var databaseName string
var companyName1 string
var companyName2 string
var companyName3 string
type indexServer struct{
  ReqType int
  Name string
  IpAddr string
  ID bson.ObjectId `bson:"_id,omitempty"`
}

var m bson.M

func errhandler(err error,something string) {
  if err != nil {
        log.Fatal(err)
        fmt.Println(something)
    }
}


func indexPut(in indexServer){
    session, err := mgo.Dial("localhost")
    errhandler(err,"connection")
    defer session.Close()
    session.SetMode(mgo.Monotonic, true)
    d := session.DB("IndexServer").C("Clients")
    err = d.Insert(&in)
    errhandler(err,"db")  
}


func dropCol(collectionName string,dbName string ){
     session, err := mgo.Dial("localhost")
     errhandler(err,"connection")
     defer session.Close()
     session.SetMode(mgo.Monotonic, true)
    
     d := session.DB(dbName).C(collectionName)
     err = d.DropCollection()
     errhandler(err,"db")
}

func indexSI(){

     //dropCol("Clients","IndexServer")
	//ID bson.ObjectId `bson:"_id,omitempty"`

     var records [6]indexServer


     records[0].ID =bson.ObjectIdHex("57dafad59b8f13c51c80ad45")
	records[1].ID =bson.ObjectIdHex("57dafad59b8f13c51c80ad46")
	records[2].ID =bson.ObjectIdHex("57dafad59b8f13c51c80ad47")
	//scanner := bufio.NewScanner(os.Stdin)


    records[0].Name=companyName1
     records[1].Name=companyName2
      records[2].Name=companyName3
     for i := 0; i < 3; i++ {
    	//fmt.Print("Enter Company Name "+strconv.Itoa(i+1)+" \n")
    	//scanner.Scan()
    	//records[i].Name = scanner.Text()
    	//fmt.Println("You have input "+scanner.Text())



    	records[i].IpAddr = "0.0.0.0" 
        indexPut(records[i])
    }
}

func collectionExist(databaseAddr string,database string) []string{
  //var result Order
  session, err := mgo.Dial(databaseAddr)
  if err != nil {
    panic(err)
  }
  defer session.Close()

  session.SetMode(mgo.Monotonic, true)
  d,_ := session.DB(database).CollectionNames()
 
  return d;
}

func main(){

if(len(os.Args)<6){
    fmt.Println("not enough arguments input")
    return;
}
if(len(os.Args)>6){
        fmt.Println("too many arguments")

        return;
}


       databaseAddr = os.Args[1]

       databaseName = os.Args[2]



        companyName1=os.Args[3]
         companyName2=os.Args[4]
        companyName3=os.Args[5]
  

    collectionExist(databaseAddr,databaseName)
	dropCol("Clients", "IndexServer")
    indexSI()

}
